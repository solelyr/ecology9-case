"use strict";

var _ecCom = ecCom,
    WeaTools = _ecCom.WeaTools; // 获取高级搜索条件

var query = function query(params) {
  console.log("Api_Params:", params);
  return WeaTools.callApi('/api/sap/finArApQuery', 'POST', params);
}; // 用于获取浏览按钮&下拉框字段显示值


var queryShowValue = function queryShowValue(params) {
  var result = "";
  $.ajax({
    url: "/api/cusWorkflow/queryShowName",
    type: 'POST',
    data: params,
    async: false,
    // 关键：设置为 false
    success: function success(rs) {
      var data = JSON.parse(rs);
      if (data.code == 200 || data.code == '200') result = data.data;
    },
    error: function error(d) {}
  });
  return result;
};

var API = {
  query: query,
  queryShowValue: queryShowValue
};
ecodeSDK.exp(API);