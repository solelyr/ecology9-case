const { WeaTools } = ecCom;

// 获取高级搜索条件
const query = params => {
  console.log("Api_Params:",params);
  return WeaTools.callApi('/api/sap/finArApQuery', 'POST', params);
};

// 用于获取浏览按钮&下拉框字段显示值
const queryShowValue = params =>{
  let result = "";
  $.ajax({
    url: "/api/cusWorkflow/queryShowName", 
    type: 'POST',
    data: params,
    async: false, // 关键：设置为 false
    success: function(rs){
      const data = JSON.parse(rs);
    	if(data.code == 200 || data.code == '200') result = data.data;
    },
    error:function(d){
      
    }
  });
  return result;
}

const API = {
  query,
  queryShowValue
}

ecodeSDK.exp(API);