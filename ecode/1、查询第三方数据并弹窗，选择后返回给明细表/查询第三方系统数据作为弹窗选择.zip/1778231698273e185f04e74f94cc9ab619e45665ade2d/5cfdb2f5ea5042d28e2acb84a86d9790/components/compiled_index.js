"use strict";

var _dec, _class, _temp;

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _mobxReact = mobxReact,
    observer = _mobxReact.observer,
    inject = _mobxReact.inject;
var _ecCom = ecCom,
    WeaDialog = _ecCom.WeaDialog;
var _antd = antd,
    message = _antd.message,
    Input = _antd.Input,
    Button = _antd.Button,
    SearchOutlined = _antd.SearchOutlined,
    Table = _antd.Table;
var NewWeaButtonDialogCom = (_dec = inject('dataStore'), _dec(_class = observer(_class = (_temp =
/*#__PURE__*/
function (_React$Component) {
  _inherits(NewWeaButtonDialogCom, _React$Component);

  function NewWeaButtonDialogCom(props) {
    var _this;

    _classCallCheck(this, NewWeaButtonDialogCom);

    //初始化，固定语法
    _this = _possibleConstructorReturn(this, _getPrototypeOf(NewWeaButtonDialogCom).call(this, props));

    _this.triggerModal = function () {
      var onClick = _this.props.dataStore.onClick;

      _this.updateScrollHeight();

      onClick();
    };

    _this.state = {
      width: 0,
      height: 0
    };
    return _this;
  }

  _createClass(NewWeaButtonDialogCom, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      ecodeSDK.setCom('${appId}', 'NewWeaButtonDialogComInstance', this); //调用接口 获取请求数据信息 为
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      // 初始化渲染页面
      var doInit = this.props.dataStore.doInit;
      console.log("调用doInit");
      doInit();
      window.addEventListener('resize', this.updateScrollHeight());
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      window.removeEventListener('resize', this.updateScrollHeight());
      ecodeSDK.setCom('${appId}', 'NewWeaButtonDialogComInstance', null);
    }
  }, {
    key: "updateScrollHeight",
    value: function updateScrollHeight() {
      var height = window.innerHeight;
      var width = window.innerWidth * 0.75; // 减去表头的高度，你也可以根据实际情况进行调整

      this.setState({
        width: width,
        height: height - 430 // 限定modulename高度100px

      });
    }
  }, {
    key: "render",
    value: function render() {
      var dataStore = this.props.dataStore;
      var onClick = dataStore.onClick,
          close = dataStore.close,
          lvisible = dataStore.lvisible,
          columns = dataStore.columns,
          dataSource = dataStore.dataSource,
          rowSelection = dataStore.rowSelection,
          selectedRowKeys = dataStore.selectedRowKeys,
          onSelectChange = dataStore.onSelectChange,
          submit = dataStore.submit,
          searchStates = dataStore.searchStates,
          updateSearchState = dataStore.updateSearchState,
          filterData = dataStore.filterData,
          resetAllFilters = dataStore.resetAllFilters,
          handleReset = dataStore.handleReset,
          filteredData = dataStore.filteredData; // const columns_new = columns;

      var columns_new = columns.map(function (item) {
        var key = item.key;
        var search_value = searchStates[key].searchText;
        return _objectSpread({}, item, {
          filterDropdown: React.createElement("div", {
            className: "ant-table-filter-dropdown",
            style: {
              padding: 4,
              width: 200
            }
          }, React.createElement(Input, {
            style: {
              "border-radius": 5
            },
            placeholder: "Search ".concat(item.title),
            value: search_value,
            onChange: function onChange(e) {
              return updateSearchState(key, e.target.value);
            },
            onPressEnter: function onPressEnter() {
              return filterData(key, search_value);
            }
          }), React.createElement("div", {
            style: {
              "padding-top": 4,
              width: 200
            }
          }, React.createElement(Button, {
            size: "small",
            type: "primary",
            icon: React.createElement(SearchOutlined, null),
            style: {
              width: 60
            },
            onClick: function onClick() {
              return filterData(key, search_value);
            }
          }, "Search"), React.createElement(Button, {
            size: "small",
            style: {
              width: 60,
              "margin-left": 4
            },
            onClick: function onClick() {
              return handleReset(key);
            }
          }, "Reset"), React.createElement(Button, {
            size: "small",
            style: {
              width: 60,
              "margin-left": 4
            },
            onClick: resetAllFilters
          }, "ResetAll")))
        });
      }); //复写组件的时候，必须带上_noOverwrite参数，避免被复写的组件又被复写导致死循环 onClick={onClick}

      return React.createElement(WeaDialog, {
        title: React.createElement("div", null, React.createElement(React.Fragment, null, "未付款情况明细 ", selectedRowKeys.length > 0 ? React.createElement(React.Fragment, null, "  已选择 " + selectedRowKeys.length + " 条数据 ", React.createElement(Button, {
          type: "primary",
          size: "small",
          onClick: submit
        }, "提交修改")) : "")),
        onCancel: close,
        visible: lvisible,
        style: {
          width: this.state.width,
          height: this.state.height + 120
        },
        hasScroll: true
      }, React.createElement(Table, {
        rowSelection: {
          selectedRowKeys: selectedRowKeys,
          onChange: onSelectChange
        },
        dataSource: filteredData,
        columns: columns_new,
        scroll: {
          x: this.state.width,
          y: this.state.height
        },
        pagination: {
          pageSize: 50
        }
      }));
    }
  }]);

  return NewWeaButtonDialogCom;
}(React.Component), _temp)) || _class) || _class); //发布模块

ecodeSDK.setCom('${appId}', 'NewWeaButtonDialogCom', NewWeaButtonDialogCom);