const { observer,inject } = mobxReact;
const {WeaDialog} = ecCom
const { message,Input,Button,SearchOutlined,Table } = antd;

@inject('dataStore')
@observer
class NewWeaButtonDialogCom extends React.Component {
  constructor(props) { //初始化，固定语法
    super(props);
    this.state = {
      width: 0,
      height: 0,
    };
  }

  componentDidMount() {
    ecodeSDK.setCom('${appId}', 'NewWeaButtonDialogComInstance', this);
    //调用接口 获取请求数据信息 为
  }

  componentWillMount() { // 初始化渲染页面
    const { dataStore: { doInit } } = this.props;
    console.log("调用doInit");
    doInit();
    window.addEventListener('resize', this.updateScrollHeight());
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.updateScrollHeight());
    ecodeSDK.setCom('${appId}', 'NewWeaButtonDialogComInstance', null);
  }

  updateScrollHeight() {
    const height = window.innerHeight;
    const width = window.innerWidth * 0.75;
    // 减去表头的高度，你也可以根据实际情况进行调整
    this.setState({ 
      width : width,
      height: height - 430, // 限定modulename高度100px
    });
  }

  triggerModal = () =>{
    const { dataStore: { onClick } } = this.props;
    this.updateScrollHeight();
    onClick();
  }

  render() {

    const { dataStore } = this.props;
    const { onClick,close,lvisible,columns,dataSource,rowSelection,selectedRowKeys,onSelectChange,submit,searchStates,
    updateSearchState,filterData,resetAllFilters ,handleReset,filteredData } = dataStore;
    // const columns_new = columns;
    const columns_new = columns.map(item => {
      const key = item.key;
      const search_value = searchStates[key].searchText;
      return {
        ...item,
        filterDropdown: (
          <div className="ant-table-filter-dropdown" style={{padding:4,width:200}}>
            <Input
              style={{"border-radius":5}}
              placeholder={`Search ${item.title}`}
              value={ search_value }
              onChange={(e) => updateSearchState(key, e.target.value)}
              onPressEnter={() => filterData(key,search_value)}
            />
            <div style={{"padding-top":4,width:200}}>
              <Button size="small" type="primary"  icon={<SearchOutlined />} style={{ width: 60 }} onClick={() => filterData(key, search_value)}>Search</Button>
              <Button size="small" style={{ width: 60,"margin-left":4 }} onClick={() => handleReset(key)}>Reset</Button>
              <Button size="small" style={{ width: 60,"margin-left":4 }} onClick={resetAllFilters}>ResetAll</Button>
            </div>
          </div>
        )
      }
    });

    //复写组件的时候，必须带上_noOverwrite参数，避免被复写的组件又被复写导致死循环 onClick={onClick}
    return (
      <WeaDialog
        title= 
          <div>
            {<>未付款情况明细 {(selectedRowKeys.length > 0 ?  
              <>{"  已选择 " + selectedRowKeys.length + " 条数据 "}
              <Button type="primary" size="small" onClick={submit} >提交修改</Button></>
            : "")}</>}
          </div>
        
        onCancel={close}
        visible={lvisible}
        style={{ width: this.state.width, height: this.state.height + 120 }}
        hasScroll
      >
        <Table 
          rowSelection={{selectedRowKeys,onChange: onSelectChange}}
          dataSource={filteredData}
          columns={columns_new} 
          scroll={{x: this.state.width, y:this.state.height}}
          pagination={{ pageSize: 50 }}
        />
      </WeaDialog>
    )
  }
}
//发布模块
ecodeSDK.setCom('${appId}','NewWeaButtonDialogCom',NewWeaButtonDialogCom);