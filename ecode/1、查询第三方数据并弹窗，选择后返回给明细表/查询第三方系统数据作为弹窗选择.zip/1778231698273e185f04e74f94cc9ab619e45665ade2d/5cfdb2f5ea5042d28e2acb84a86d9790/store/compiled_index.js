"use strict";

var DataStore = ecodeSDK.imp(DataStore);
var allStore = {
  dataStore: new DataStore()
};
ecodeSDK.exp(allStore);