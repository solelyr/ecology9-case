"use strict";

var _class, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _descriptor14, _descriptor15, _descriptor16, _descriptor17, _descriptor18, _descriptor19, _descriptor20, _descriptor21, _descriptor22, _descriptor23, _descriptor24, _descriptor25, _temp;

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and set to use loose mode. ' + 'To use proposal-class-properties in spec mode with decorators, wait for ' + 'the next major version of decorators in stage 2.'); }

var _mobx = mobx,
    observable = _mobx.observable,
    action = _mobx.action,
    toJS = _mobx.toJS;
var _antd = antd,
    message = _antd.message;
var _ecCom = ecCom,
    WeaLoadingGlobal = _ecCom.WeaLoadingGlobal;
var layoutStore = WfForm.getLayoutStore();
var API = ecodeSDK.imp(API);
var DataStore = (_class = (_temp =
/*#__PURE__*/
function () {
  function DataStore() {
    _classCallCheck(this, DataStore);

    _initializerDefineProperty(this, "lvisible", _descriptor, this);

    _initializerDefineProperty(this, "columns", _descriptor2, this);

    _initializerDefineProperty(this, "selectedRowKeys", _descriptor3, this);

    _initializerDefineProperty(this, "selectedRowDatas", _descriptor4, this);

    _initializerDefineProperty(this, "dataSource", _descriptor5, this);

    _initializerDefineProperty(this, "detailField", _descriptor6, this);

    _initializerDefineProperty(this, "mainField", _descriptor7, this);

    _initializerDefineProperty(this, "queryParams", _descriptor8, this);

    _initializerDefineProperty(this, "mainData", _descriptor9, this);

    _initializerDefineProperty(this, "paramsStatus", _descriptor10, this);

    _initializerDefineProperty(this, "searchStates", _descriptor11, this);

    _initializerDefineProperty(this, "filteredData", _descriptor12, this);

    _initializerDefineProperty(this, "filteredDataKeys", _descriptor13, this);

    _initializerDefineProperty(this, "doInit", _descriptor14, this);

    _initializerDefineProperty(this, "setColumns", _descriptor15, this);

    _initializerDefineProperty(this, "close", _descriptor16, this);

    _initializerDefineProperty(this, "onSelectChange", _descriptor17, this);

    _initializerDefineProperty(this, "setMainData", _descriptor18, this);

    _initializerDefineProperty(this, "checkParams", _descriptor19, this);

    _initializerDefineProperty(this, "onClick", _descriptor20, this);

    _initializerDefineProperty(this, "submit", _descriptor21, this);

    this.getHasDetail = function () {
      var list = [];
      var belnr = WfForm.convertFieldNameToId("BELNR", "detail_1"); // 凭证号

      var buzei = WfForm.convertFieldNameToId("BUZEI", "detail_1"); // 行号
      // 案例通过 belnr + buzei拼接的结果作为key值

      var rowArr = WfForm.getDetailAllRowIndexStr("detail_1").split(",");

      for (var i = 0; i < rowArr.length; i++) {
        var rowIndex = rowArr[i];

        if (rowIndex !== "") {
          var belnr_value = WfForm.getFieldValue(belnr + "_" + rowIndex);
          var buzei_value = WfForm.getFieldValue(buzei + "_" + rowIndex);
          list.push(belnr_value + "_" + buzei_value);
        }
      }

      return list;
    };

    _initializerDefineProperty(this, "updateSearchState", _descriptor22, this);

    _initializerDefineProperty(this, "filterData", _descriptor23, this);

    _initializerDefineProperty(this, "handleReset", _descriptor24, this);

    _initializerDefineProperty(this, "resetAllFilters", _descriptor25, this);
  }

  _createClass(DataStore, [{
    key: "compare",
    // 排序
    value: function compare(property) {
      return function (a, b) {
        var value1 = a[property];
        var value2 = b[property];
        return value1 - value2; // return value2 - value1; 降序
      };
    }
  }]);

  return DataStore;
}(), _temp), (_descriptor = _applyDecoratedDescriptor(_class.prototype, "lvisible", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return false;
  }
}), _descriptor2 = _applyDecoratedDescriptor(_class.prototype, "columns", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return [];
  }
}), _descriptor3 = _applyDecoratedDescriptor(_class.prototype, "selectedRowKeys", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return [];
  }
}), _descriptor4 = _applyDecoratedDescriptor(_class.prototype, "selectedRowDatas", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return [];
  }
}), _descriptor5 = _applyDecoratedDescriptor(_class.prototype, "dataSource", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return [];
  }
}), _descriptor6 = _applyDecoratedDescriptor(_class.prototype, "detailField", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return {};
  }
}), _descriptor7 = _applyDecoratedDescriptor(_class.prototype, "mainField", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return {};
  }
}), _descriptor8 = _applyDecoratedDescriptor(_class.prototype, "queryParams", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return {
      budatStart: "",
      // 过账日期-开始日期
      budatEnd: "",
      // 过账日期-结束日期
      whlb: "",
      // 是否客户类型
      kunnr: "",
      // 客户号
      lifnr: "",
      // 供应商号
      bukrs: "",
      // 公司代码
      xnorm: "",
      // 普通业务
      xshbv: "",
      // 特别总账业务
      spras: "1" // 语言

    };
  }
}), _descriptor9 = _applyDecoratedDescriptor(_class.prototype, "mainData", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return {};
  }
}), _descriptor10 = _applyDecoratedDescriptor(_class.prototype, "paramsStatus", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return true;
  }
}), _descriptor11 = _applyDecoratedDescriptor(_class.prototype, "searchStates", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return {};
  }
}), _descriptor12 = _applyDecoratedDescriptor(_class.prototype, "filteredData", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return {};
  }
}), _descriptor13 = _applyDecoratedDescriptor(_class.prototype, "filteredDataKeys", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return [];
  }
}), _descriptor14 = _applyDecoratedDescriptor(_class.prototype, "doInit", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this = this;

    return function () {
      _this.columns = _this.setColumns(); // 设置弹窗显示需要的列，该案例中弹窗显示的列和表单明细表1完全一致，因此读取了明细表1的列配置。

      _this.detailField = {};
      _this.mainField = {};
      var tableInfo = mobx.toJS(layoutStore.tableInfo);
      var detailFieldInfo = tableInfo["detail_1"].fieldinfomap;
      detailFieldInfo && Object.keys(detailFieldInfo).map(function (key) {
        var _detailFieldInfo$key = detailFieldInfo[key],
            fieldname = _detailFieldInfo$key.fieldname,
            fieldlabel = _detailFieldInfo$key.fieldlabel,
            detailtype = _detailFieldInfo$key.detailtype;
        if (fieldname !== undefined && fieldname !== "") _this.detailField[fieldname.toLowerCase()] = {
          "fieldId": key,
          "fieldlabel": fieldlabel,
          "detailtype": detailtype
        };
      });
      var mainFieldInfo = tableInfo["main"].fieldinfomap;
      mainFieldInfo && Object.keys(mainFieldInfo).map(function (key) {
        var fieldname = mainFieldInfo[key].fieldname;
        var fieldlabel = mainFieldInfo[key].fieldlabel;
        if (fieldname !== undefined && fieldname !== "") _this.mainField[fieldname.toLowerCase()] = {
          "fieldId": key,
          "fieldlabel": fieldlabel
        };
      });
    };
  }
}), _descriptor15 = _applyDecoratedDescriptor(_class.prototype, "setColumns", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this2 = this;

    return function () {
      var detailId = "detail_1";
      var detailMap = mobx.toJS(layoutStore.dataJson.etables);
      var detail_1 = detailMap[detailId].ec;
      var colattrs = detailMap[detailId].colattrs; // 是否隐藏列

      var colheads = detailMap[detailId].colheads; // 自定义列宽

      var columns = [];

      for (var i = 0; i < detail_1.length; i++) {
        var v = detail_1[i];
        var idArr = v.id.split(',');
        if (!v.field || idArr[0] !== "1") continue; // 判断是否隐藏行

        var hasHide = colattrs["col_" + idArr[1]] && colattrs["col_" + idArr[1]].hide === "y" ? true : false;
        var key = 'field' + v.field + "_show";
        var title = v.evalue;
        _this2.searchStates[key] = {
          searchText: '',
          filterDropdownVisible: false
        };
        columns.push({
          title: title,
          key: key,
          className: hasHide ? "detail_hide_col" : "",
          dataIndex: 'field' + v.field + "_show",
          hasHide: hasHide,
          index: idArr[1],
          width: colheads["col_" + idArr[1]],
          style: {
            "width": colheads["col_" + idArr[1]]
          }
        });
      }

      columns = columns.sort(_this2.compare("index"));
      return columns;
    };
  }
}), _descriptor16 = _applyDecoratedDescriptor(_class.prototype, "close", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this3 = this;

    return function () {
      _this3.lvisible = false;
    };
  }
}), _descriptor17 = _applyDecoratedDescriptor(_class.prototype, "onSelectChange", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this4 = this;

    return function (selectedRowKeys, row) {
      _this4.selectedRowKeys = selectedRowKeys;
      _this4.selectedRowDatas = row;
    };
  }
}), _descriptor18 = _applyDecoratedDescriptor(_class.prototype, "setMainData", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this5 = this;

    return function () {
      var mainDataMap = mobx.toJS(layoutStore.mainData);
      mainDataMap && Object.keys(mainDataMap).map(function (key) {
        _this5.mainData[key.replace("field", "")] = mainDataMap[key].value;
      });
    };
  }
}), _descriptor19 = _applyDecoratedDescriptor(_class.prototype, "checkParams", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this6 = this;

    return function () {
      // 设置并确认参数是否完成
      var whlb = _this6.mainData[_this6.mainField["whlb"].fieldId];
      if (whlb == "" || whlb == undefined) whlb = 0;
      var msg = "";
      _this6.paramsStatus = true;
      Object.keys(_this6.queryParams).map(function (key) {
        var fieldName = key.toLocaleLowerCase();
        var fieldMap = _this6.mainField[fieldName];

        if (fieldMap !== undefined && Object.keys(fieldMap).length > 0) {
          var fieldId = fieldMap.fieldId;
          var fieldLabel = fieldMap.fieldlabel;
          var dataValue = _this6.mainData[fieldId];

          if ("kunnr" == fieldName || "lifnr" == fieldName) {
            // 客户或者供应商
            if ((whlb == 0 && "kunnr" == fieldName || whlb == 1 && "lifnr" == fieldName) && (dataValue == "" || dataValue == undefined)) msg += msg !== "" ? "," + fieldLabel : fieldLabel;
          } else if (dataValue == "" || dataValue == undefined) {
            // 非客户或供应商
            msg += msg !== "" ? "," + fieldLabel : fieldLabel;
          }

          _this6.queryParams[key] = dataValue;
        }
      });

      if (msg !== "") {
        _this6.paramsStatus = false;
        message.error('"' + msg + '"字段值为空，请填写后再点击查询！', 5);
        WeaLoadingGlobal.end(); // 停止遮罩loading

        WeaLoadingGlobal.destroy(); // 销毁
      }
    };
  }
}), _descriptor20 = _applyDecoratedDescriptor(_class.prototype, "onClick", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this7 = this;

    return function () {
      try {
        WeaLoadingGlobal.start({
          tip: "正在查询SAP数据，请等待..."
        });

        if (Object.keys(_this7.detailField).length == 0 || Object.keys(_this7.mainField).length == 0) {
          message.error("系统初始异常，请刷新页面并重试！", 5);
          WeaLoadingGlobal.end(); // 停止遮罩loading

          WeaLoadingGlobal.destroy(); // 销毁

          return;
        }

        _this7.setMainData();

        _this7.checkParams();

        if (!_this7.paramsStatus) return;
        API.query(_this7.queryParams).then(action(function (res) {
          if (res.code == 200 || res.code == "200") {
            var dataList = [];
            var i = 0;
            res.data && res.data.forEach(function (item) {
              var dataMap = {
                key: i++
              };
              item && Object.keys(item).map(function (key) {
                var field = _this7.detailField[key];

                if (field !== "" && field !== undefined && field != "undefined") {
                  var detail_key = field.fieldId;

                  if (detail_key !== "" && detail_key !== undefined) {
                    var detailtype = field.detailtype; // 表单字段类型

                    var value = item[key];
                    var value_show = value;

                    if (detailtype == 161) {
                      value_show = API.queryShowValue({
                        "fieldId": detail_key,
                        "value": value
                      }); // 查询显示值

                      if (value_show === '' || value_show === undefined) value_show = value;
                    }

                    dataMap["field" + detail_key + "_show"] = value_show;
                    dataMap["field" + detail_key] = value;
                  }
                }
              });
              dataList.push(dataMap);
            });
            _this7.dataSource = dataList;
            _this7.filteredData = dataList;
            _this7.lvisible = true;
          } else {
            message.error("查询未结清数据失败！" + res.errMsg, 5);
          }

          WeaLoadingGlobal.end(); // 停止遮罩loading

          WeaLoadingGlobal.destroy(); // 销毁
        }));
      } catch (e) {
        WeaLoadingGlobal.end(); // 停止遮罩loading

        WeaLoadingGlobal.destroy(); // 销毁

        console.log("error:", e);
        message.error("发生未知错误，请联系管理员处理！", 5); // setTimeout(function() { location.reload(); }, 3000);
      }
    };
  }
}), _descriptor21 = _applyDecoratedDescriptor(_class.prototype, "submit", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this8 = this;

    return function () {
      // 提交
      // WfForm.delDetailRow("detail_1", "all"); // 先删除明细表所有行
      var hasList = _this8.getHasDetail(); // 明细表中已选择的数据


      var belnr = WfForm.convertFieldNameToId("BELNR", "detail_1"); // 凭证号

      var buzei = WfForm.convertFieldNameToId("BUZEI", "detail_1"); // 行号

      _this8.selectedRowKeys && _this8.selectedRowKeys.forEach(function (row) {
        var data = _this8.dataSource.filter(function (record) {
          if (record.key === row) return true;
        });

        if (data && data[0]) {
          var item = data[0];
          var belnr_value = item[belnr];
          var buzei_value = item[buzei];
          var key_value = belnr_value + "_" + buzei_value;

          if (hasList.indexOf(key_value) === -1) {
            var addObj = {};
            Object.keys(item).map(function (key) {
              if (key.indexOf("_show") === -1 && key !== 'key') {
                var showKey = key + "_show";
                var value = item[key];
                var showValue = item[showKey];
                addObj[key] = {
                  value: value,
                  specialobj: [{
                    id: value,
                    name: showValue
                  }]
                };
              }
            });
            WfForm.addDetailRow("detail_1", addObj);
          }
        }
      });
      _this8.lvisible = false;
    };
  }
}), _descriptor22 = _applyDecoratedDescriptor(_class.prototype, "updateSearchState", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this9 = this;

    return function (key, newState) {
      var searchStates = _this9.searchStates;
      searchStates[key] = _objectSpread({}, _this9.searchStates[key], {
        searchText: newState
      });
      _this9.searchStates = {};
      _this9.searchStates = searchStates;
    };
  }
}), _descriptor23 = _applyDecoratedDescriptor(_class.prototype, "filterData", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this10 = this;

    return function () {
      _this10.filteredDataKeys = []; // 清空数组

      var filteredData = _this10.dataSource.filter(function (record) {
        // 先遍历每一行数据，然后遍历所有的查询key，然后根据查询key来判断返回的数据
        // 检查每个列的搜索条件
        for (var key in _this10.searchStates) {
          var searchText = _this10.searchStates[key].searchText;
          if (searchText == "") continue;
          var reg = new RegExp(searchText, 'gi');
          if (record[key] == undefined) return false;
          var columnValue = record[key].toString();

          if (!columnValue.match(reg)) {
            return false; // 如果任何一个条件不满足，则返回false
          }
        }

        record['key'] && _this10.filteredDataKeys.push(record['key']);
        return true; // 如果所有条件都满足，则返回true
      });

      _this10.filteredData = filteredData;
    };
  }
}), _descriptor24 = _applyDecoratedDescriptor(_class.prototype, "handleReset", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this11 = this;

    return function (columnKey) {
      // 清除所有搜索文本为初始状态
      _this11.updateSearchState(columnKey, ''); // 重新进行过滤


      _this11.filterData();
    };
  }
}), _descriptor25 = _applyDecoratedDescriptor(_class.prototype, "resetAllFilters", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this12 = this;

    return function () {
      // 重置所有搜索状态和过滤数据
      Object.keys(_this12.searchStates).map(function (item) {
        _this12.updateSearchState(item, '');
      }); // 重新进行过滤

      _this12.filterData();
    };
  }
})), _class);
ecodeSDK.exp(DataStore);