const { observable, action, toJS } = mobx;
const { message } = antd;
const { WeaLoadingGlobal } = ecCom;
const layoutStore = WfForm.getLayoutStore();
const API = ecodeSDK.imp(API);

class DataStore {
  @observable lvisible = false;
  @observable columns = [];
  @observable selectedRowKeys = [];
  @observable selectedRowDatas = [];
  @observable dataSource = [];
  @observable detailField = {};
  @observable mainField = {};

  // 第三方系统接口入参字段
  @observable queryParams = {
    budatStart:"", // 过账日期-开始日期
    budatEnd:"", // 过账日期-结束日期
    whlb:"", // 是否客户类型
    kunnr:"", // 客户号
    lifnr:"", // 供应商号
    bukrs:"", // 公司代码
    xnorm:"", // 普通业务
    xshbv:"", // 特别总账业务
    spras:"1" // 语言
  };
  
  @observable mainData = {};
  @observable paramsStatus = true;
  @observable searchStates = {};
  @observable filteredData= {};
  @observable filteredDataKeys=[];


  @action
  doInit = () => {
    this.columns = this.setColumns(); // 设置弹窗显示需要的列，该案例中弹窗显示的列和表单明细表1完全一致，因此读取了明细表1的列配置。

    this.detailField= {};
    this.mainField = {};
    const tableInfo = mobx.toJS(layoutStore.tableInfo);
    const detailFieldInfo = tableInfo["detail_1"].fieldinfomap;
    detailFieldInfo && Object.keys(detailFieldInfo).map((key) =>{
      const { fieldname,fieldlabel,detailtype } = detailFieldInfo[key];
      if(fieldname !== undefined && fieldname !== "") this.detailField[fieldname.toLowerCase()]={"fieldId":key,"fieldlabel":fieldlabel,"detailtype":detailtype};
    });

    const mainFieldInfo = tableInfo["main"].fieldinfomap;
    mainFieldInfo && Object.keys(mainFieldInfo).map((key) =>{
      const fieldname = mainFieldInfo[key].fieldname;
      const fieldlabel = mainFieldInfo[key].fieldlabel;
      if(fieldname !== undefined && fieldname !== "") this.mainField[fieldname.toLowerCase()]={"fieldId":key,"fieldlabel":fieldlabel};
    });
  }

  @action
  setColumns = () =>{
    const detailId = "detail_1";
    const detailMap = mobx.toJS(layoutStore.dataJson.etables);
    const detail_1 = detailMap[detailId].ec;
    const colattrs = detailMap[detailId].colattrs;// 是否隐藏列
    const colheads = detailMap[detailId].colheads;// 自定义列宽
    let columns = [];
    for(let i = 0;i<detail_1.length;i++){ 
      const v = detail_1[i];
      const idArr = v.id.split(',');
      if(!v.field || idArr[0]!=="1") continue;

      // 判断是否隐藏行
      const hasHide = colattrs["col_"+idArr[1]]&&colattrs["col_"+idArr[1]].hide==="y"?true:false;
      const key = 'field'+v.field+"_show";
      const title = v.evalue;
      this.searchStates[key] = {searchText : '',filterDropdownVisible: false};
      columns.push({
        title,key,
        className: hasHide?"detail_hide_col":"",
        dataIndex: 'field'+v.field+"_show",
        hasHide:hasHide,
        index:idArr[1],
        width:colheads["col_"+idArr[1]],
        style:{"width":colheads["col_"+idArr[1]],},
      });
    }
    columns=columns.sort(this.compare("index"));
    return columns;
  }

  // 排序
  compare(property){
    return function (a, b) {
      var value1 = a[property];
      var value2 = b[property];
      return value1 - value2;
      // return value2 - value1; 降序
    }
  }

  @action 
  close = () =>{
    this.lvisible = false;
  }

  @action
  onSelectChange = (selectedRowKeys,row) =>{
    this.selectedRowKeys = selectedRowKeys;
    this.selectedRowDatas = row;
  }


  @action
  setMainData = () =>{
    const mainDataMap = mobx.toJS(layoutStore.mainData);
    mainDataMap && Object.keys(mainDataMap).map((key) => {
      this.mainData[key.replace("field","")]=mainDataMap[key].value;
    })
  }

  @action
  checkParams = () => {
    // 设置并确认参数是否完成
    let whlb = this.mainData[this.mainField["whlb"].fieldId];
    if(whlb == "" || whlb == undefined) whlb = 0;
    let msg = "";
    this.paramsStatus = true;
    Object.keys(this.queryParams).map((key) => {
      const fieldName = key.toLocaleLowerCase();
      const fieldMap = this.mainField[fieldName];
      if(fieldMap !== undefined && Object.keys(fieldMap).length > 0 ){
        const fieldId = fieldMap.fieldId;
        const fieldLabel = fieldMap.fieldlabel;
        const dataValue = this.mainData[fieldId];

        if("kunnr" == fieldName || "lifnr" == fieldName){
          // 客户或者供应商
          if(((whlb == 0 && "kunnr" == fieldName) || (whlb == 1 && "lifnr" == fieldName)) && (dataValue == "" || dataValue == undefined)) msg += (msg !== "" ? ","+fieldLabel : fieldLabel);
        }else if(dataValue == "" || dataValue == undefined){
          // 非客户或供应商
          msg += (msg !== "" ? ","+fieldLabel : fieldLabel);
        }

        this.queryParams[key] = dataValue;
      }
    })
    if(msg !== "") {
      this.paramsStatus = false;
      message.error('"' + msg + '"字段值为空，请填写后再点击查询！',5);
      WeaLoadingGlobal.end(); // 停止遮罩loading
      WeaLoadingGlobal.destroy(); // 销毁
    }

  }

  @action
  onClick = () => {
    try{
      WeaLoadingGlobal.start({tip: "正在查询SAP数据，请等待..."});
      if(Object.keys(this.detailField).length == 0 || Object.keys(this.mainField).length == 0){
        message.error("系统初始异常，请刷新页面并重试！",5);
        WeaLoadingGlobal.end(); // 停止遮罩loading
        WeaLoadingGlobal.destroy(); // 销毁
        return ;
      }
      this.setMainData();
      this.checkParams();
      if(!this.paramsStatus) return;
      API.query(this.queryParams).then(action(res => {
        if(res.code == 200 || res.code == "200"){
          const dataList = [];
          let i = 0;
          res.data && res.data.forEach(item => {
            const dataMap = {key:i++};
            item && Object.keys(item).map((key) =>{
              const field = this.detailField[key];
              if(field !== "" && field !== undefined && field != "undefined"){
                const detail_key = field.fieldId;
                if(detail_key !== "" && detail_key !== undefined){
                  const detailtype = field.detailtype; // 表单字段类型
                  const value = item[key];
                  let value_show = value;
                  if(detailtype == 161 ){
                    value_show = API.queryShowValue({"fieldId":detail_key,"value":value}); // 查询显示值
                    if(value_show === '' || value_show === undefined) value_show = value;
                  }
                  dataMap["field"+detail_key+"_show"] = value_show;
                  dataMap["field"+detail_key] = value;
                }
              }
            });
            dataList.push(dataMap);
          })
          this.dataSource = dataList;
          this.filteredData = dataList;
          this.lvisible = true;
        }else{
          message.error("查询未结清数据失败！"+res.errMsg,5);
        }
        WeaLoadingGlobal.end(); // 停止遮罩loading
        WeaLoadingGlobal.destroy(); // 销毁
      }));
      
    }catch(e){
      WeaLoadingGlobal.end(); // 停止遮罩loading
      WeaLoadingGlobal.destroy(); // 销毁
      console.log("error:",e);
      message.error("发生未知错误，请联系管理员处理！",5);
      // setTimeout(function() { location.reload(); }, 3000);
    }
  }

  @action
  submit = () =>{
    // 提交
    // WfForm.delDetailRow("detail_1", "all"); // 先删除明细表所有行
    const hasList = this.getHasDetail(); // 明细表中已选择的数据
    const belnr = WfForm.convertFieldNameToId("BELNR","detail_1"); // 凭证号
    const buzei = WfForm.convertFieldNameToId("BUZEI","detail_1"); // 行号
    this.selectedRowKeys && this.selectedRowKeys.forEach(row=>{
      const data = this.dataSource.filter(record =>{if(record.key === row) return true;})
      if(data && data[0]){
        const item = data[0];
        const belnr_value = item[belnr];
        const buzei_value = item[buzei];
        const key_value = belnr_value+"_"+buzei_value;
        if(hasList.indexOf(key_value) === -1) {
          var addObj = {};
          Object.keys(item).map((key) => {
            if(key.indexOf("_show") === -1 && key !== 'key') {
              const showKey = key + "_show";
              const value = item[key];
              const showValue = item[showKey];
              addObj[key] = {
                value:value,
                specialobj:[
                  {id:value,name:showValue}
                ]
              };
            }
          })
          WfForm.addDetailRow("detail_1", addObj);
        }
      }
    })
    this.lvisible = false;
  }

  getHasDetail =() =>{
    const list = [];
    const belnr = WfForm.convertFieldNameToId("BELNR","detail_1"); // 凭证号
    const buzei = WfForm.convertFieldNameToId("BUZEI","detail_1"); // 行号
    // 案例通过 belnr + buzei拼接的结果作为key值
    var rowArr = WfForm.getDetailAllRowIndexStr("detail_1").split(",");
    for(var i=0; i<rowArr.length; i++){
      var rowIndex = rowArr[i];
      if(rowIndex !== ""){
          var belnr_value = WfForm.getFieldValue(belnr + "_" + rowIndex);
          var buzei_value = WfForm.getFieldValue(buzei + "_" + rowIndex);
          list.push(belnr_value+"_"+buzei_value);
      }
    }
    return list;
  }

  @action
  updateSearchState = (key, newState) => {
    const searchStates = this.searchStates;
    searchStates[key] = {
      ...this.searchStates[key],
      searchText: newState
    };
    this.searchStates = {};
    this.searchStates = searchStates;
  }

  // 搜索动作，案例走的是前端匹配查询
  @action
  filterData = () => {
    this.filteredDataKeys = []; // 清空数组
    const filteredData = this.dataSource.filter(record => {
      // 先遍历每一行数据，然后遍历所有的查询key，然后根据查询key来判断返回的数据
      // 检查每个列的搜索条件
      for (const key in this.searchStates) {
        const searchText = this.searchStates[key].searchText;
        if(searchText=="") continue;
        const reg = new RegExp(searchText, 'gi');
        if(record[key] == undefined) return false;
        const columnValue = record[key].toString();
        if (!columnValue.match(reg)) {
          return false; // 如果任何一个条件不满足，则返回false
        }
      }
      record['key'] && this.filteredDataKeys.push(record['key']);
      return true; // 如果所有条件都满足，则返回true
    });
    this.filteredData = filteredData;
  }

  // 单列内容清除
  @action
  handleReset = (columnKey) => {
    // 清除所有搜索文本为初始状态
    this.updateSearchState(columnKey,'');
    // 重新进行过滤
    this.filterData();
  }

  // 清除全部内容
  @action
  resetAllFilters = () => {
    // 重置所有搜索状态和过滤数据
    Object.keys(this.searchStates).map(item=>{
      this.updateSearchState(item,'');
    })
    // 重新进行过滤
    this.filterData();
  }

}

ecodeSDK.exp(DataStore);