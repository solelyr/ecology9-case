const DataStore = ecodeSDK.imp(DataStore);

const allStore = { dataStore:new DataStore() }

ecodeSDK.exp(allStore);