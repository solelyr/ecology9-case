let enable = true; //总开关
let isRun = false; //控制执行次数

const ConfigParams = ecodeSDK.getCom('${appId}', 'ConfigParams'); // 从配置文件读取

const showDialog = ()=>{
  //获取子组件对象
  let instance = ecodeSDK.getCom('${appId}','NewWeaButtonDialogComInstance');
  //调用子组件方法 传递参数
  instance && instance.triggerModal();
}
 
const runScript = (formid)=>{ //代码块钩子，类似放在代码块中或者jquery.ready
  const {configs}=ConfigParams;
  if(configs.hasOwnProperty(formid)){
    let config=configs[formid];
    config.forEach(item => {
      const { fieldName } = item
      const fieldId = WfForm.convertFieldNameToId(fieldName);
      const {Button} = antd;
      window.WfForm.proxyFieldContentComp(fieldId.replace("field",""), (info, compFn) => {
        return (<Button type="primary" size="small" onClick= {showDialog}>查询未付款情况</Button>);
      })
      // window.WfForm.forceRenderField(fieldId);
    })
  }
}

const run = () => {
  runScript(WfForm.getBaseInfo().formid); //执行代码块
  isRun = true; //确保只执行一次
}

ecodeSDK.overwritePropsFnQueueMapSet('WeaReqTop',{
  fn:(newProps)=>{
    if(!enable) return ; //总开关打开
    if(!ConfigParams.enable) return ; //配置开关打开
    const {hash} = window.location;
    if(!hash.startsWith('#/main/workflow/req')) return;      // const baseInfo = WfForm.getBaseInfo();
    if(!WfForm) return ; //表单sdk加载完成
    if(!WfForm.getBaseInfo()) return;
    const {formid} = WfForm.getBaseInfo();
    const {configs}=ConfigParams;
    if(!formid || formid == undefined || configs[formid] == undefined) return;
    // console.log("isRun:",isRun,",formid:",formid,",configs:",configs[formid]);
    const acParams = {
      appId:'${appId}',
      name:'NewWeaButtonDialogCom', //具体页面应用id
      isPage:true, //是否是路由页面
      noCss:true, //是否禁止单独加载css，通常为了减少css数量，css默认前置加载
    }
    const AddCom = ecodeSDK.getAsyncCom(acParams);
    newProps.children.push(<AddCom />);
    if(isRun) return ; //执行过一次就不执行
    run() //执行代码块
    return newProps;
  },
  order:3,
  desc:'查询第三方系统数据作为弹窗选择'
});