# 流程表单新增按钮并点击触发列表弹框
##功能描述
1、接口查询第三方数据，主表字段作为条件入参
2、根据返回的第三方数据弹窗显示，选择后将数据写入明细表中
##截图
![查询条件](${appRes}/image1.png)
![查询结果](${appRes}/image2.png "查询结果")
##相关资料
antd 表单组件地址如下
https://cloudstore.e-cology.cn/#/pc/component/table/demo-0