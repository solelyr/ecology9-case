"use strict";

var enable = true; //总开关

var isRun = false; //控制执行次数

var ConfigParams = ecodeSDK.getCom('${appId}', 'ConfigParams'); // 从配置文件读取

var showDialog = function showDialog() {
  //获取子组件对象
  var instance = ecodeSDK.getCom('${appId}', 'NewWeaButtonDialogComInstance'); //调用子组件方法 传递参数

  instance && instance.triggerModal();
};

var runScript = function runScript(formid) {
  //代码块钩子，类似放在代码块中或者jquery.ready
  var configs = ConfigParams.configs;

  if (configs.hasOwnProperty(formid)) {
    var config = configs[formid];
    config.forEach(function (item) {
      var fieldName = item.fieldName;
      var fieldId = WfForm.convertFieldNameToId(fieldName);
      var _antd = antd,
          Button = _antd.Button;
      window.WfForm.proxyFieldContentComp(fieldId.replace("field", ""), function (info, compFn) {
        return React.createElement(Button, {
          type: "primary",
          size: "small",
          onClick: showDialog
        }, "查询未付款情况");
      }); // window.WfForm.forceRenderField(fieldId);
    });
  }
};

var run = function run() {
  runScript(WfForm.getBaseInfo().formid); //执行代码块

  isRun = true; //确保只执行一次
};

ecodeSDK.overwritePropsFnQueueMapSet('WeaReqTop', {
  fn: function fn(newProps) {
    if (!enable) return; //总开关打开

    if (!ConfigParams.enable) return; //配置开关打开

    var hash = window.location.hash;
    if (!hash.startsWith('#/main/workflow/req')) return; // const baseInfo = WfForm.getBaseInfo();

    if (!WfForm) return; //表单sdk加载完成

    if (!WfForm.getBaseInfo()) return;

    var _WfForm$getBaseInfo = WfForm.getBaseInfo(),
        formid = _WfForm$getBaseInfo.formid;

    var configs = ConfigParams.configs;
    if (!formid || formid == undefined || configs[formid] == undefined) return; // console.log("isRun:",isRun,",formid:",formid,",configs:",configs[formid]);

    var acParams = {
      appId: '${appId}',
      name: 'NewWeaButtonDialogCom',
      //具体页面应用id
      isPage: true,
      //是否是路由页面
      noCss: true //是否禁止单独加载css，通常为了减少css数量，css默认前置加载

    };
    var AddCom = ecodeSDK.getAsyncCom(acParams);
    newProps.children.push(React.createElement(AddCom, null));
    if (isRun) return; //执行过一次就不执行

    run(); //执行代码块

    return newProps;
  },
  order: 3,
  desc: '查询第三方系统数据作为弹窗选择'
});