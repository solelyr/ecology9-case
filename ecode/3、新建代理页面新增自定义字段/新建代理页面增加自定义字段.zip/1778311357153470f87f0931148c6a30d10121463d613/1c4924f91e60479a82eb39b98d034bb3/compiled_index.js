"use strict";

var _dec, _class, _temp;

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _mobxReact = mobxReact,
    inject = _mobxReact.inject,
    observer = _mobxReact.observer;
var _ecCom = ecCom,
    WeaDialog = _ecCom.WeaDialog,
    WeaSearchGroup = _ecCom.WeaSearchGroup,
    WeaInput = _ecCom.WeaInput,
    WeaFormItem = _ecCom.WeaFormItem;
var _antd = antd,
    Switch = _antd.Switch,
    Row = _antd.Row,
    Button = _antd.Button;
var _comsMobx = comsMobx,
    WeaSwitch = _comsMobx.WeaSwitch;
var NewCustomField = (_dec = inject('wfAgentStore'), _dec(_class = observer(_class = (_temp =
/*#__PURE__*/
function (_React$Component) {
  _inherits(NewCustomField, _React$Component);

  function NewCustomField(props) {
    var _this;

    _classCallCheck(this, NewCustomField);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(NewCustomField).call(this, props));

    _this.handleSave = function () {
      var wfAgentStore = _this.props.wfAgentStore;
      var addAgentForm = wfAgentStore.addAgentForm,
          addAgentFlag = wfAgentStore.addAgentFlag,
          addAgentDatas = wfAgentStore.addAgentDatas;
      var formParams = addAgentForm.getFormParams();
      console.log("提交给后端的结果：", mobx.toJS(formParams));
    };

    return _this;
  }

  _createClass(NewCustomField, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          items = _this$props.items,
          wfAgentStore = _this$props.wfAgentStore;
      var addAgentDatas = wfAgentStore.addAgentDatas,
          addAgentForm = wfAgentStore.addAgentForm,
          formParams = wfAgentStore.formParams;
      var config = ecodeSDK.getCom('${appId}', 'config'); // 读取配置文件

      items.push({
        colSpan: 1,
        com: React.createElement(WeaFormItem, {
          label: config.label // 前端显示的名称
          ,
          labelCol: {
            span: 6
          },
          wrapperCol: {
            span: 18
          }
        }, React.createElement("div", {
          className: "wf-agent-rangeleft"
        }, React.createElement(WeaSwitch, {
          fieldConfig: addAgentDatas[config.fieldId] // 需要和domKey保持一致
          ,
          form: addAgentForm,
          formParams: formParams
        })))
      });
      return React.createElement(React.Fragment, null, React.createElement(WeaSearchGroup, _extends({}, this.props, {
        items: items,
        _noOverWrite: true
      })));
    }
  }]);

  return NewCustomField;
}(React.Component), _temp)) || _class) || _class);
ecodeSDK.setCom('${appId}', 'NewCustomField', NewCustomField);