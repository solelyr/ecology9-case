const { inject,observer } = mobxReact;
const { WeaDialog,WeaSearchGroup,WeaInput, WeaFormItem } = ecCom;
const { Switch,Row,Button } = antd;
const { WeaSwitch } = comsMobx;

@inject('wfAgentStore')
@observer
class NewCustomField extends React.Component {
  constructor(props) {
      super(props);
  }

  handleSave = () =>  {
    const {wfAgentStore} = this.props;
    const {addAgentForm,addAgentFlag,addAgentDatas} = wfAgentStore;
    const formParams = addAgentForm.getFormParams();
    console.log("提交给后端的结果：",mobx.toJS(formParams));
  }

  render() {
    const { items,wfAgentStore } = this.props;
    const { addAgentDatas,addAgentForm,formParams } = wfAgentStore;
    const config = ecodeSDK.getCom('${appId}', 'config'); // 读取配置文件
    items.push({
      colSpan: 1,
      com:
        <WeaFormItem
          label={config.label} // 前端显示的名称
          labelCol={{span: 6}}
          wrapperCol={{span: 18}}
        >
          <div className="wf-agent-rangeleft">
            <WeaSwitch
              fieldConfig={addAgentDatas[config.fieldId]} // 需要和domKey保持一致
              form={addAgentForm}
              formParams={formParams}
            />
          </div>
        </WeaFormItem>
    })
    return (
      <>
        <WeaSearchGroup {...this.props} items={items}  _noOverWrite />
        {
          // 这一段是测试用的，打开后会有一个按钮，可以显示提交的结果
          // <Button type="primary" onClick={this.handleSave}>
          //   Click me!
          // </Button>
        }
      </>
    )
  }
}

ecodeSDK.setCom('${appId}', 'NewCustomField', NewCustomField);