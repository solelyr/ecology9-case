"use strict";

var config = ecodeSDK.getCom('${appId}', 'config');

var NewCustomField = function NewCustomField(props) {
  var acParams = {
    appId: '${appId}',
    name: 'NewCustomField',
    isPage: false,
    noCss: true,
    props: props
  };
  return ecodeSDK.getAsyncCom(acParams);
};

ecodeSDK.overwriteClassFnQueueMapSet('WeaSearchGroup', {
  // 组件重写
  fn: function fn(Com, newProps) {
    if (!config) return;
    if (!config.enable) return;
    var hash = window.location.hash;
    if (!hash.startsWith(config.path)) return;
    if (!window.comsMobx) return;
    if (newProps.ecId !== "_Route@wnzyk8_AddAgent@eazo47_WeaSearchGroup@1hzomc@addgroup") return; // console.log("拦截到了弹窗！",newProps.items);

    if (newProps._noOverWrite) return;
    return {
      com: NewCustomField,
      props: newProps
    };
  }
});