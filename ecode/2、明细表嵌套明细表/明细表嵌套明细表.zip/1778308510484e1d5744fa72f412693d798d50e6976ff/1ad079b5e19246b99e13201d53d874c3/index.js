const {WeaTable} = ecCom; //可以用antd Table的所有api
const { observer } = mobxReact;
const globalStore = WfForm.getGlobalStore();
const layoutStore = WfForm.getLayoutStore();

@observer
class WfDetailData extends React.Component {
  constructor(props) {
    super(props);
    this.state={}
  }

// 获取字段列
  getColumns(detailId,hideFields){
    // console.log("test:",mobx.toJS(window.WfForm.getLayoutStore()));
    const detailMap = mobx.toJS(window.WfForm.getLayoutStore().detailMap);
    // console.log("detailId:",detailId,"detailMap:",detailMap);
    const {isadd,iscopy,isdelete,isedit,isneed} = detailMap[detailId].attr;
    const detailTables = mobx.toJS(window.WfForm.getLayoutStore().dataJson.etables);
    const detail_1 = detailTables[detailId].ec;
    const colattrs = detailTables[detailId].colattrs;// 是否隐藏列
    const colheads = detailTables[detailId].colheads;// 自定义列宽
    let columns = [];
    for(let i = 0;i<detail_1.length;i++){ 
      const v = detail_1[i];
      const idArr = v.id.split(',');
      if(!v.field || idArr[0]!=="1") continue;

      // 判断是否隐藏行
      const hasHide = colattrs["col_"+idArr[1]]&&colattrs["col_"+idArr[1]].hide==="y"?true:false;
      columns.push({
        title: v.evalue,
        className: hasHide?"detail_hide_col":"rzw_mainDetail_tr_th",
        dataIndex: 'field'+v.field,
        key: 'field'+v.field,
        hasHide:hasHide,
        index:idArr[1],
        width:colheads["col_"+idArr[1]],
        style:{"width":colheads["col_"+idArr[1]],}
      });
    }
      
      columns=columns.sort(compare("index"));
      
      return {columns,isadd,iscopy,isdelete,isedit,isneed};
  }
// 排序
 compare(property){
      return function (a, b) {
          var value1 = a[property];
          var value2 = b[property];
          return value1 - value2;
          // return value2 - value1; 降序
      }
  }

  
  add(button_id,key,props){
    // 增加行
    const{mainCollectionField,mainDetail,detail,collectionField,addData} = props;
    const mainFieldId = WfForm.convertFieldNameToId(mainCollectionField, mainDetail);
    const mainValue = WfForm.getFieldValue(mainFieldId+"_"+key);

    const detail_fieldId = WfForm.convertFieldNameToId(collectionField,detail);
    // console.log("增加行",key,",mainFieldId:",mainFieldId,",value:",mainValue);
    if(mainValue===""||mainValue===undefined) return WfForm.showMessage("标识字段内容不能为空！请先填写标识字段内容！", 2, 10);  //错误信息，10s后消失; 
    // 给子明细表增加行
    var addObj = {};
    addObj[detail_fieldId] = {
      value:mainValue,
      specialobj:[{
        id:mainValue,
        name:WfForm.getBrowserShowName(mainFieldId+"_"+key)
      }]
    };
    addData && Object.keys(addData).map(item =>{
      const value_key = addData[item];
      const mainId = WfForm.convertFieldNameToId(item, mainDetail);
      const detailId = WfForm.convertFieldNameToId(value_key, detail);

      const mainValue1 = WfForm.getFieldValue(mainId+"_"+key);
      addObj[detailId] = {
        value:mainValue1,
        specialobj:[{
          id:mainValue1,
          name:WfForm.getBrowserShowName(mainId+"_"+key)
        }]
      }
    })

    WfForm.addDetailRow(detail, addObj);
  }

  show(button_id,key,props){
    var info = document.getElementById(button_id);
    var tr = document.getElementById("rzw_tr_child_"+key);
    // 显示子组件
    if(info.className==="icon-coms-Browse-box-Add-to") {
      info.classList.replace("icon-coms-Browse-box-Add-to","icon-coms-down2");
      if(tr != '' && tr != undefined) tr.style="display:";
    }else{
      // 隐藏子组件
      info.classList.replace("icon-coms-down2","icon-coms-Browse-box-Add-to");
      if(tr != '' && tr != undefined) tr.style="display:none";
    }
  }

  del(button_id,key,props){
    const{detail} = props;
    WfForm.delDetailRow(detail, key); 
  }


  getFieldIds(columns,row){
    let datas=[];
    columns && columns.map(a=>(datas.push(
      { field:a.dataIndex+"_"+row,
        className:a.hasHide?"detail_hide_col":"rzw_mainDetail_tbody_td",
      }
      )));
    return datas;
  }

  getMainDatas(){    
    const {mainDetail,detail,mainHideFields} = this.props;
    const {columns,isadd,isdelete} = this.getColumns(mainDetail,mainHideFields);
    const allRowId = WfForm.getDetailAllRowIndexStr(mainDetail).split(",")||'';
    let mainDatas=[];
    allRowId[0]!==""&&allRowId.map(row=>{
      const{hasChild,datas,childColumns} = this.getChildDatas(row);

        mainDatas.push({
          props:this.props,    
          tr_id:"rzw_tr_"+row,
          fieldIds:this.getFieldIds(columns,row),
          key:row,
          isadd:isadd,
          buttons:[{"id":"show_"+row,classname:"icon-coms-down2","onClick":this.show},
                   {"id":"add_"+row,classname:isdelete==1?"icon-coms-Add-to-hot":"detail_hide_col","onClick":this.add}],       
          child:hasChild?<NewTableRzw columns={childColumns} datas={datas} isdelete={isdelete} isChild={1}/>:"",
      })
    })

    return mainDatas;
  }

  getChildDatas(i){
    const{mainCollectionField,mainDetail,detail,collectionField,hideFields} = this.props;
    const mainFieldId = WfForm.convertFieldNameToId(mainCollectionField, mainDetail);
    const mainValue = WfForm.getFieldValue(mainFieldId+"_"+i);
    const detail_fieldId = WfForm.convertFieldNameToId(collectionField,detail);
    // const {columns} = util.getDetailObj(detail,hideFields);
    const {columns,isadd,isdelete} = this.getColumns(detail,hideFields);
    const allRowId = WfForm.getDetailAllRowIndexStr(detail).split(",")|| '';
    let datas=[];
    let hasChild = false;
    allRowId&&allRowId.map(row=>{
      if(mainValue!==""&&mainValue==WfForm.getFieldValue(detail_fieldId+"_"+row)){
        hasChild = true;
        datas.push({
          props:this.props,
          tr_id:"rzw_child_tr_"+row,
          fieldIds:this.getFieldIds(columns,row),
          key:row,
          isadd:isadd,
          isdelete:isdelete,
          buttons:[{
            "id":"del_child_"+row,
            "classname":isdelete===1?"icon-coms-form-delete-hot":"detail_hide_col",
            "onClick":this.del}], 
        })
      }
    })
    return {datas:datas,hasChild:hasChild,childColumns:columns};
  }

  render() {
    // console.log("二阶段的渲染！",this.props,",state:",this.state);
    const {mainDetail,mainHideFields} = this.props;

    // const {columns} = util.getDetailObj(mainDetail,mainHideFields);
    const {columns,isdelete} = this.getColumns(mainDetail,mainHideFields);
    const datas = this.getMainDatas();
    // console.log("二阶段的渲染！columns：",columns,",data:",datas);
    return (
      <NewTableRzw columns={columns} datas={datas} isdelete={isdelete} isChild={0}/>
    )
  }
}


//发布模块WfCom，作为模块${appId}的子模块
ecodeSDK.setCom('${appId}','WfDetailData',WfDetailData);