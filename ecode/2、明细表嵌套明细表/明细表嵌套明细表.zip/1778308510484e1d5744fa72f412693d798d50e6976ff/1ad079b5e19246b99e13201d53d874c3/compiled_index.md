"use strict";

var enable = true;
var isRun = false; //控制执行次数

var config = {
  "-1058": {
    // 渲染的位置字段，建一个没用的字段放着就好了
    fieldName: 'xry',
    // 主明细表
    mainDetail: 'detail_1',
    // 主明细表的标识字段
    mainCollectionField: 'mxid',
    // 副明细表
    detail: 'detail_2',
    // 副明细表的关联字段。
    collectionField: 'mxid',
    addData: {
      cltx_oa_rwn: "cltx_oa_rwn",
      // sap预留行号
      mtrl_code: "mtrl_code",
      wlmc: "wlmc",
      cltx_use_dept: "cltx_use_dept"
    }
  }
};

var runScript = function runScript(params) {
  //代码块钩子，类似放在代码块中或者jquery.ready
  //返回自定义渲染的组件
  var acParams = {
    appId: '${appId}',
    name: 'WfDetailData',
    //具体页面应用id
    isPage: true,
    //是否是路由页面
    noCss: true //是否禁止单独加载css，通常为了减少css数量，css默认前置加载

  };
  console.log("params:", params);
  var NewCom = ecodeSDK.getAsyncCom(acParams);
  var fieldId = WfForm.convertFieldNameToId(params.fieldName);
  WfForm.proxyFieldContentComp(fieldId.replace("field", ""), function (info, compFn) {
    return React.createElement(NewCom, params);
  });
  WfForm.forceRenderField(fieldId);
  isRun = true; //确保只执行一次
}; //PC端代码块
//利用组件复写作为代码块执行钩子，这种方案可以支持覆盖到所有流程，也可以判断到指定流程指定节点


ecodeSDK.overwritePropsFnQueueMapSet('WeaReqTop', {
  fn: function fn(newProps) {
    if (!enable) return; //开关打开

    var hash = window.location.hash;
    if (!hash.startsWith('#/main/workflow/req')) return; //判断页面地址

    if (!ecCom.WeaTools.Base64) return; //完整组件库加载完成

    if (!WfForm) return; //表单sdk加载完成

    var baseInfo = WfForm.getBaseInfo();
    var formid = baseInfo.formid;
    if (!config[formid]) return; //判断流程id

    if (isRun) return; //执行过一次就不执行

    runScript(config[formid]); //执行代码块
  }
});