//  2023-06-25 备注 没有在使用
  const getDetailObj=(detailId,hideFields)=> {
    // console.log("getLayoutStore:",window.WfForm.getLayoutStore());
    const detailMap = mobx.toJS(window.WfForm.getLayoutStore().detailMap);
    const detail_1 = detailMap[detailId];
    const pagingInfo = detail_1.pagingInfo;
    // console.log("detail_1:",detailId,",map:",detail_1);
    let columns = [];
    for(let k in detail_1.fieldInfo) {
      const v = detail_1.fieldInfo[k];
      // console.log("v:",v);
      const hasHide = isHide1('field'+v.fieldid,hideFields);
      columns.push({
        title: v.fieldlabel,
        className: hasHide===-1?"rzw_mainDetail_tr_th":"detail_hide_col",
        dataIndex: 'field'+v.fieldid,
        key: 'field'+v.fieldid,
        hasHide:hasHide===-1?false:true
      });
    }

    const allRowIndex = WfForm.getDetailAllRowIndexStr(detailId);
    const allRowArr = allRowIndex.split(',');
    let dataSource = [];
    for(let i=0;i<allRowArr.length;i++) {
      let row = {key:allRowArr[i]};
      let fields=[];
      for(let j=0;j<columns.length;j++) {
        const c = columns[j];
        fields.push(c.dataIndex+'_'+allRowArr[i]);
        const obj = detail_1.detailData[c.dataIndex+'_'+allRowArr[i]]||{};
        row[c.dataIndex] = obj.value||"";
      }
      row["fields"]=fields;
      dataSource.push(row);
    } 
    return {
      columns,
      dataSource,
      pagingInfo
    }
  }

const isHide1=(fieldid,hideFields)=>{
  // console.log("hideFields:",hideFields,",fieldid:",fieldid,",ishas:",hideFields.indexOf(fieldid));
  return hideFields.indexOf(fieldid);
}  

const getColumns=(detailId,hideFields)=>{
  const detailMap = mobx.toJS(window.WfForm.getLayoutStore().dataJson.etables);
  const detail_1 = detailMap[detailId].ec;
  const colattrs = detailMap[detailId].colattrs;// 是否隐藏列
  const colheads = detailMap[detailId].colheads;// 自定义列宽
  let columns = [];
  for(let i = 0;i<detail_1.length;i++){ 
    const v = detail_1[i];
    const idArr = v.id.split(',');
    if(!v.field || idArr[0]!=="1") continue;

    // 判断是否隐藏行
    const hasHide = colattrs["col_"+idArr[1]]&&colattrs["col_"+idArr[1]].hide==="y"?true:false;
    columns.push({
      title: v.evalue,
      className: hasHide?"detail_hide_col":"rzw_mainDetail_tr_th",
      dataIndex: 'field'+v.field,
      key: 'field'+v.field,
      hasHide:hasHide,
      index:idArr[1],
      width:colheads["col_"+idArr[1]],
      style:{"width":colheads["col_"+idArr[1]],}
    });
  }
    
    columns=columns.sort(compare("index"));

    return columns;
}

const compare=(property)=> {
    return function (a, b) {
        var value1 = a[property];
        var value2 = b[property];
        return value1 - value2;
        // return value2 - value1; 降序
    }
}

const util = {
  getDetailObj,
  getColumns
}
  
//发布模块
ecodeSDK.exp(util);