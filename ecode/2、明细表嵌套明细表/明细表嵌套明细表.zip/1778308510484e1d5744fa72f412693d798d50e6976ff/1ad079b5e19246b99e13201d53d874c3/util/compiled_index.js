"use strict";

//  2023-06-25 备注 没有在使用
var getDetailObj = function getDetailObj(detailId, hideFields) {
  // console.log("getLayoutStore:",window.WfForm.getLayoutStore());
  var detailMap = mobx.toJS(window.WfForm.getLayoutStore().detailMap);
  var detail_1 = detailMap[detailId];
  var pagingInfo = detail_1.pagingInfo; // console.log("detail_1:",detailId,",map:",detail_1);

  var columns = [];

  for (var k in detail_1.fieldInfo) {
    var v = detail_1.fieldInfo[k]; // console.log("v:",v);

    var hasHide = isHide1('field' + v.fieldid, hideFields);
    columns.push({
      title: v.fieldlabel,
      className: hasHide === -1 ? "rzw_mainDetail_tr_th" : "detail_hide_col",
      dataIndex: 'field' + v.fieldid,
      key: 'field' + v.fieldid,
      hasHide: hasHide === -1 ? false : true
    });
  }

  var allRowIndex = WfForm.getDetailAllRowIndexStr(detailId);
  var allRowArr = allRowIndex.split(',');
  var dataSource = [];

  for (var i = 0; i < allRowArr.length; i++) {
    var row = {
      key: allRowArr[i]
    };
    var fields = [];

    for (var j = 0; j < columns.length; j++) {
      var c = columns[j];
      fields.push(c.dataIndex + '_' + allRowArr[i]);
      var obj = detail_1.detailData[c.dataIndex + '_' + allRowArr[i]] || {};
      row[c.dataIndex] = obj.value || "";
    }

    row["fields"] = fields;
    dataSource.push(row);
  }

  return {
    columns: columns,
    dataSource: dataSource,
    pagingInfo: pagingInfo
  };
};

var isHide1 = function isHide1(fieldid, hideFields) {
  // console.log("hideFields:",hideFields,",fieldid:",fieldid,",ishas:",hideFields.indexOf(fieldid));
  return hideFields.indexOf(fieldid);
};

var getColumns = function getColumns(detailId, hideFields) {
  var detailMap = mobx.toJS(window.WfForm.getLayoutStore().dataJson.etables);
  var detail_1 = detailMap[detailId].ec;
  var colattrs = detailMap[detailId].colattrs; // 是否隐藏列

  var colheads = detailMap[detailId].colheads; // 自定义列宽

  var columns = [];

  for (var i = 0; i < detail_1.length; i++) {
    var v = detail_1[i];
    var idArr = v.id.split(',');
    if (!v.field || idArr[0] !== "1") continue; // 判断是否隐藏行

    var hasHide = colattrs["col_" + idArr[1]] && colattrs["col_" + idArr[1]].hide === "y" ? true : false;
    columns.push({
      title: v.evalue,
      className: hasHide ? "detail_hide_col" : "rzw_mainDetail_tr_th",
      dataIndex: 'field' + v.field,
      key: 'field' + v.field,
      hasHide: hasHide,
      index: idArr[1],
      width: colheads["col_" + idArr[1]],
      style: {
        "width": colheads["col_" + idArr[1]]
      }
    });
  }

  columns = columns.sort(compare("index"));
  return columns;
};

var compare = function compare(property) {
  return function (a, b) {
    var value1 = a[property];
    var value2 = b[property];
    return value1 - value2; // return value2 - value1; 降序
  };
};

var util = {
  getDetailObj: getDetailObj,
  getColumns: getColumns //发布模块

};
ecodeSDK.exp(util);