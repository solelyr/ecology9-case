"use strict";

var _class;

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _ecCom = ecCom,
    WeaTable = _ecCom.WeaTable; //可以用antd Table的所有api

var _mobxReact = mobxReact,
    observer = _mobxReact.observer;
var globalStore = WfForm.getGlobalStore();
var layoutStore = WfForm.getLayoutStore();

var WfDetailData = observer(_class =
/*#__PURE__*/
function (_React$Component) {
  _inherits(WfDetailData, _React$Component);

  function WfDetailData(props) {
    var _this;

    _classCallCheck(this, WfDetailData);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(WfDetailData).call(this, props));
    _this.state = {};
    return _this;
  } // 获取字段列


  _createClass(WfDetailData, [{
    key: "getColumns",
    value: function getColumns(detailId, hideFields) {
      // console.log("test:",mobx.toJS(window.WfForm.getLayoutStore()));
      var detailMap = mobx.toJS(window.WfForm.getLayoutStore().detailMap); // console.log("detailId:",detailId,"detailMap:",detailMap);

      var _detailMap$detailId$a = detailMap[detailId].attr,
          isadd = _detailMap$detailId$a.isadd,
          iscopy = _detailMap$detailId$a.iscopy,
          isdelete = _detailMap$detailId$a.isdelete,
          isedit = _detailMap$detailId$a.isedit,
          isneed = _detailMap$detailId$a.isneed;
      var detailTables = mobx.toJS(window.WfForm.getLayoutStore().dataJson.etables);
      var detail_1 = detailTables[detailId].ec;
      var colattrs = detailTables[detailId].colattrs; // 是否隐藏列

      var colheads = detailTables[detailId].colheads; // 自定义列宽

      var columns = [];

      for (var i = 0; i < detail_1.length; i++) {
        var v = detail_1[i];
        var idArr = v.id.split(',');
        if (!v.field || idArr[0] !== "1") continue; // 判断是否隐藏行

        var hasHide = colattrs["col_" + idArr[1]] && colattrs["col_" + idArr[1]].hide === "y" ? true : false;
        columns.push({
          title: v.evalue,
          className: hasHide ? "detail_hide_col" : "rzw_mainDetail_tr_th",
          dataIndex: 'field' + v.field,
          key: 'field' + v.field,
          hasHide: hasHide,
          index: idArr[1],
          width: colheads["col_" + idArr[1]],
          style: {
            "width": colheads["col_" + idArr[1]]
          }
        });
      }

      columns = columns.sort(compare("index"));
      return {
        columns: columns,
        isadd: isadd,
        iscopy: iscopy,
        isdelete: isdelete,
        isedit: isedit,
        isneed: isneed
      };
    } // 排序

  }, {
    key: "compare",
    value: function compare(property) {
      return function (a, b) {
        var value1 = a[property];
        var value2 = b[property];
        return value1 - value2; // return value2 - value1; 降序
      };
    }
  }, {
    key: "add",
    value: function add(button_id, key, props) {
      // 增加行
      var mainCollectionField = props.mainCollectionField,
          mainDetail = props.mainDetail,
          detail = props.detail,
          collectionField = props.collectionField,
          addData = props.addData;
      var mainFieldId = WfForm.convertFieldNameToId(mainCollectionField, mainDetail);
      var mainValue = WfForm.getFieldValue(mainFieldId + "_" + key);
      var detail_fieldId = WfForm.convertFieldNameToId(collectionField, detail); // console.log("增加行",key,",mainFieldId:",mainFieldId,",value:",mainValue);

      if (mainValue === "" || mainValue === undefined) return WfForm.showMessage("标识字段内容不能为空！请先填写标识字段内容！", 2, 10); //错误信息，10s后消失; 
      // 给子明细表增加行

      var addObj = {};
      addObj[detail_fieldId] = {
        value: mainValue,
        specialobj: [{
          id: mainValue,
          name: WfForm.getBrowserShowName(mainFieldId + "_" + key)
        }]
      };
      addData && Object.keys(addData).map(function (item) {
        var value_key = addData[item];
        var mainId = WfForm.convertFieldNameToId(item, mainDetail);
        var detailId = WfForm.convertFieldNameToId(value_key, detail);
        var mainValue1 = WfForm.getFieldValue(mainId + "_" + key);
        addObj[detailId] = {
          value: mainValue1,
          specialobj: [{
            id: mainValue1,
            name: WfForm.getBrowserShowName(mainId + "_" + key)
          }]
        };
      });
      WfForm.addDetailRow(detail, addObj);
    }
  }, {
    key: "show",
    value: function show(button_id, key, props) {
      var info = document.getElementById(button_id);
      var tr = document.getElementById("rzw_tr_child_" + key); // 显示子组件

      if (info.className === "icon-coms-Browse-box-Add-to") {
        info.classList.replace("icon-coms-Browse-box-Add-to", "icon-coms-down2");
        if (tr != '' && tr != undefined) tr.style = "display:";
      } else {
        // 隐藏子组件
        info.classList.replace("icon-coms-down2", "icon-coms-Browse-box-Add-to");
        if (tr != '' && tr != undefined) tr.style = "display:none";
      }
    }
  }, {
    key: "del",
    value: function del(button_id, key, props) {
      var detail = props.detail;
      WfForm.delDetailRow(detail, key);
    }
  }, {
    key: "getFieldIds",
    value: function getFieldIds(columns, row) {
      var datas = [];
      columns && columns.map(function (a) {
        return datas.push({
          field: a.dataIndex + "_" + row,
          className: a.hasHide ? "detail_hide_col" : "rzw_mainDetail_tbody_td"
        });
      });
      return datas;
    }
  }, {
    key: "getMainDatas",
    value: function getMainDatas() {
      var _this2 = this;

      var _this$props = this.props,
          mainDetail = _this$props.mainDetail,
          detail = _this$props.detail,
          mainHideFields = _this$props.mainHideFields;

      var _this$getColumns = this.getColumns(mainDetail, mainHideFields),
          columns = _this$getColumns.columns,
          isadd = _this$getColumns.isadd,
          isdelete = _this$getColumns.isdelete;

      var allRowId = WfForm.getDetailAllRowIndexStr(mainDetail).split(",") || '';
      var mainDatas = [];
      allRowId[0] !== "" && allRowId.map(function (row) {
        var _this2$getChildDatas = _this2.getChildDatas(row),
            hasChild = _this2$getChildDatas.hasChild,
            datas = _this2$getChildDatas.datas,
            childColumns = _this2$getChildDatas.childColumns;

        mainDatas.push({
          props: _this2.props,
          tr_id: "rzw_tr_" + row,
          fieldIds: _this2.getFieldIds(columns, row),
          key: row,
          isadd: isadd,
          buttons: [{
            "id": "show_" + row,
            classname: "icon-coms-down2",
            "onClick": _this2.show
          }, {
            "id": "add_" + row,
            classname: isdelete == 1 ? "icon-coms-Add-to-hot" : "detail_hide_col",
            "onClick": _this2.add
          }],
          child: hasChild ? React.createElement(NewTableRzw, {
            columns: childColumns,
            datas: datas,
            isdelete: isdelete,
            isChild: 1
          }) : ""
        });
      });
      return mainDatas;
    }
  }, {
    key: "getChildDatas",
    value: function getChildDatas(i) {
      var _this3 = this;

      var _this$props2 = this.props,
          mainCollectionField = _this$props2.mainCollectionField,
          mainDetail = _this$props2.mainDetail,
          detail = _this$props2.detail,
          collectionField = _this$props2.collectionField,
          hideFields = _this$props2.hideFields;
      var mainFieldId = WfForm.convertFieldNameToId(mainCollectionField, mainDetail);
      var mainValue = WfForm.getFieldValue(mainFieldId + "_" + i);
      var detail_fieldId = WfForm.convertFieldNameToId(collectionField, detail); // const {columns} = util.getDetailObj(detail,hideFields);

      var _this$getColumns2 = this.getColumns(detail, hideFields),
          columns = _this$getColumns2.columns,
          isadd = _this$getColumns2.isadd,
          isdelete = _this$getColumns2.isdelete;

      var allRowId = WfForm.getDetailAllRowIndexStr(detail).split(",") || '';
      var datas = [];
      var hasChild = false;
      allRowId && allRowId.map(function (row) {
        if (mainValue !== "" && mainValue == WfForm.getFieldValue(detail_fieldId + "_" + row)) {
          hasChild = true;
          datas.push({
            props: _this3.props,
            tr_id: "rzw_child_tr_" + row,
            fieldIds: _this3.getFieldIds(columns, row),
            key: row,
            isadd: isadd,
            isdelete: isdelete,
            buttons: [{
              "id": "del_child_" + row,
              "classname": isdelete === 1 ? "icon-coms-form-delete-hot" : "detail_hide_col",
              "onClick": _this3.del
            }]
          });
        }
      });
      return {
        datas: datas,
        hasChild: hasChild,
        childColumns: columns
      };
    }
  }, {
    key: "render",
    value: function render() {
      // console.log("二阶段的渲染！",this.props,",state:",this.state);
      var _this$props3 = this.props,
          mainDetail = _this$props3.mainDetail,
          mainHideFields = _this$props3.mainHideFields; // const {columns} = util.getDetailObj(mainDetail,mainHideFields);

      var _this$getColumns3 = this.getColumns(mainDetail, mainHideFields),
          columns = _this$getColumns3.columns,
          isdelete = _this$getColumns3.isdelete;

      var datas = this.getMainDatas(); // console.log("二阶段的渲染！columns：",columns,",data:",datas);

      return React.createElement(NewTableRzw, {
        columns: columns,
        datas: datas,
        isdelete: isdelete,
        isChild: 0
      });
    }
  }]);

  return WfDetailData;
}(React.Component)) || _class; //发布模块WfCom，作为模块${appId}的子模块


ecodeSDK.setCom('${appId}', 'WfDetailData', WfDetailData);