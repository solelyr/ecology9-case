"use strict";

var _class;

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _mobxReact = mobxReact,
    observer = _mobxReact.observer;
var _mobxReact2 = mobxReact,
    Provider = _mobxReact2.Provider;

var NewTableRzw = observer(_class =
/*#__PURE__*/
function (_React$Component) {
  _inherits(NewTableRzw, _React$Component);

  function NewTableRzw(props) {
    _classCallCheck(this, NewTableRzw);

    return _possibleConstructorReturn(this, _getPrototypeOf(NewTableRzw).call(this, props));
  }

  _createClass(NewTableRzw, [{
    key: "getButtons",
    value: function getButtons(buttons, key, props, isdelete, isChild) {
      return React.createElement("td", {
        className: isdelete !== 1 && isChild == 1 ? "detail_hide_col" : "rzw_mainDetail_tbody_td"
      }, React.createElement("div", {
        style: {
          "display": "flex",
          "justify-content": "center",
          "align-items": "center"
        }
      }, buttons.map(function (button) {
        return React.createElement("div", {
          id: button.id,
          style: {
            "padding": "2px"
          },
          className: button.classname,
          onClick: function onClick() {
            return button.onClick(button.id, key, props);
          }
        });
      })));
    }
  }, {
    key: "getDatas",
    value: function getDatas(fieldIds) {
      return fieldIds.map(function (fieldId) {
        return React.createElement("td", {
          className: fieldId.className
        }, WfForm.generateFieldContentComp(fieldId.field), " ");
      });
    }
  }, {
    key: "getChilDatas",
    value: function getChilDatas(child, colspan, key) {
      return React.createElement("tr", {
        id: "rzw_tr_child_" + key
      }, React.createElement("td", {
        className: "rzw_childDetail_tbody_td"
      }), React.createElement("td", {
        colspan: colspan,
        style: {
          "padding": "2px"
        },
        className: "rzw_childDetail_tbody_td"
      }, child));
    }
  }, {
    key: "render",
    value: function render() {
      var _this = this;

      var _this$props = this.props,
          columns = _this$props.columns,
          datas = _this$props.datas,
          isdelete = _this$props.isdelete,
          isChild = _this$props.isChild; // console.log("第三次渲染：",this.props);

      console.log("datas:", datas);
      return React.createElement("div", {
        className: "rzw_detail"
      }, React.createElement(Provider, {
        globalStore: globalStore,
        layoutStore: layoutStore
      }, React.createElement("table", {
        style: {
          "border-collapse": "collapse",
          "width": "100%"
        }
      }, React.createElement("thead", null, React.createElement("tr", {
        className: "rzw_mainDetail_tr"
      }, React.createElement("th", {
        className: isdelete !== 1 && isChild === 1 ? "detail_hide_col" : "rzw_mainDetail_tr_th",
        style: {
          "width": "6%"
        }
      }, " "), columns && columns.map(function (a) {
        return React.createElement("th", {
          className: a.className,
          style: a.style
        }, " ", a.title);
      }))), React.createElement("tbody", null, datas && datas.map(function (data) {
        return React.createElement(React.Fragment, null, React.createElement("tr", {
          id: data.tr_id
        }, data.buttons && _this.getButtons(data.buttons, data.key, data.props, isdelete, isChild), data.fieldIds && _this.getDatas(data.fieldIds)), data.child && _this.getChilDatas(data.child, columns.length, data.key));
      })))));
    }
  }]);

  return NewTableRzw;
}(React.Component)) || _class; //发布模块WfCom，作为模块${appId}的子模块


ecodeSDK.setCom('${appId}', 'NewTableRzw', NewTableRzw);