const { observer } = mobxReact;
const {Provider}=mobxReact;

@observer
class NewTableRzw extends React.Component {
  constructor(props) {
    super(props);
  }

  
  getButtons(buttons,key,props,isdelete,isChild){
    return(
      <td className={isdelete!==1&&isChild==1?"detail_hide_col":"rzw_mainDetail_tbody_td"}>
        <div style={{"display":"flex","justify-content": "center","align-items": "center"}}>
          {buttons.map(button=>(<div id={button.id} style={{"padding":"2px"}} className = {button.classname} onClick={()=>button.onClick(button.id,key,props)} />))}
        </div>
      </td>)
  }

  getDatas(fieldIds){
    return fieldIds.map(fieldId=>(<td className={fieldId.className}>{WfForm.generateFieldContentComp(fieldId.field)} </td>))
  }

  getChilDatas(child,colspan,key){
    return (
      <tr id={"rzw_tr_child_"+key}>
        <td className="rzw_childDetail_tbody_td" >
        </td>
        <td colspan={colspan} style={{"padding": "2px"}} className={"rzw_childDetail_tbody_td"}>
          {child}
        </td>
      </tr>)
  }

  render() {
    const {columns,datas,isdelete,isChild} = this.props;
    // console.log("第三次渲染：",this.props);
    console.log("datas:",datas);
    return (
      <div className = "rzw_detail">
        <Provider globalStore={globalStore} layoutStore={layoutStore}>
          <table style={{"border-collapse":"collapse","width":"100%"}}>
            <thead>
              <tr className="rzw_mainDetail_tr">
                <th className={isdelete!==1&&isChild===1?"detail_hide_col":"rzw_mainDetail_tr_th"} style={{"width":"6%"}}> </th>
                {columns&&columns.map(a => (<th className={a.className} style={a.style}> {a.title}</th>))}
              </tr>
            </thead>
            <tbody>
              {datas&&datas.map(data=>(<>
                {<tr id={data.tr_id} >
                  {data.buttons&&this.getButtons(data.buttons,data.key,data.props,isdelete,isChild)}
                  {data.fieldIds&&this.getDatas(data.fieldIds)}
                </tr>}
                  {data.child&&this.getChilDatas(data.child,columns.length,data.key)}
              </>))}
            </tbody> 
          </table>
        </Provider>
      </div>
    )
  }
}
  //发布模块WfCom，作为模块${appId}的子模块
ecodeSDK.setCom('${appId}','NewTableRzw',NewTableRzw);